#include<stdio.h>
int main(){
  int x = 0;
  while( x++ <= 5 ) {
    printf("%d\n",x);
  } 
}

