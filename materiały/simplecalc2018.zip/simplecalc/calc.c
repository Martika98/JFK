#include<stdio.h>
int main(){
  int x,y;
  x = 4+y+8;
  scanf("%d",&x);
  printf("%d\n",x+y);
}

