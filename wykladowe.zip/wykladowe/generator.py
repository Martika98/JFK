class Generator:
    main_text = ''
    reg = 1

    def assign(self):

