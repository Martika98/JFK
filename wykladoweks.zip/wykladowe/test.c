#include <stdio.h>

int main()
{
    //double a = 6.2;
    //double b = 3.4; 
    //printf("%f", a/b);
    double a = 4.2;
    double b = 2.1;
    double c = a - b;
    
    //printf("%f", 6.2/3.4);
    return 0;
}

